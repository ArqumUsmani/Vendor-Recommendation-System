// $(document).ready(function() {

// });
M.AutoInit();
$(document).ready(function(){
    $('.fixed-action-btn').floatingActionButton();
    $('.tabs').tabs();
    $('.collapsible').collapsible();
    $('select').formSelect();
    $('.tooltipped').tooltip();
    $('.modal').modal();
  });
